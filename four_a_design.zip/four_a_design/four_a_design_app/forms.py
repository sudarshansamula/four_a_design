from django import forms
from .models import user_list,userApplication

class ListForm(forms.ModelForm):
    class Meta:
        model = user_list
        fields=["name","email","password"]