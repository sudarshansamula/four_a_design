from django.db import models

# Create your models here.
class user_list(models.Model):
    name = models.CharField('user_name',max_length=200)
    email = models.CharField('email',max_length=50,unique=True)
    password = models.CharField('password',max_length=50,default=None)

    def __str__(self):
        return self.email + ' | ' + self.password

class userApplication(models.Model):
    name = models.CharField('user_name',max_length=200)
    email = models.CharField('email',max_length=50,unique=True)
    phone = models.BigIntegerField('phone',default=None)
    skills = models.CharField('skills',max_length=200)
    description = models.TextField('description',blank=True,max_length=500)
    status = models.CharField('status',max_length=200)


    def __str__(self):
        return self