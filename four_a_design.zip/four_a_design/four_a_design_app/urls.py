from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('home', views.home,name="home"),
     path('', views.userForm,name="userForm"),
    path('updateStatus',views.updateStatus,name="updateStatus"),
    path('getUserdata/logout',views.logout,name="logout"),
    path('getUserdata/<list_id>',views.getUserdata,name="getUserdata"),
    path('loadAdminHomepage',views.loadAdminHomepage,name="loadAdminHomepage"),
    path('loginUser',views.loginUser,name="loginUser"),
    path('backTOuser',views.backTOuser,name="backTOuser"),
    path('logout',views.logout,name="logout"),
    path('userSubmission',views.userSubmission,name="userSubmission"),
    
]