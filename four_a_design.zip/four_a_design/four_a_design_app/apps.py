from django.apps import AppConfig


class FourADesignAppConfig(AppConfig):
    name = 'four_a_design_app'
