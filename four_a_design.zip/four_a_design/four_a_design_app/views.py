from django.shortcuts import render,redirect,render_to_response
from .models import user_list
from .models import userApplication
from django.http import HttpResponse
from .forms import ListForm
from django.contrib import messages
import json
from django.db import connection,transaction
cursor = connection.cursor()
# Create your views here.
def backTOuser(request):
    return render_to_response('userApplication.html')
def userForm(request):
    return render_to_response('userApplication.html') 
def home(request):
    id=1
    if request.method == 'POST':
        form =ListForm(request.POST or None)
        print("getting item alue",request.POST.get('item'),request.POST.get('completed'))
        if form.is_valid():
            new_patron=form.save()
            all_items= userApplication.objects.all
            messages.success(request,('Item has been Added To List'))
            print("new_patron",new_patron)
            return render(request,'admin.html',{'all_items':all_items,'id':id})
        else:
            all_items=userApplication.objects.all
            return render(request,'admin.html',{'all_items':all_items,'id':id})
    else:
        all_items=userApplication.objects.all
        return render(request,'admin.html',{'all_items':all_items,'id':id})
def loadAdminHomepage(request):
    return render(request,'admin_login.html',{})
def logout(request):
    request.session.clear()
    return redirect(loadAdminHomepage)
def loginUser(request):
    data={'email':"",'password':""}
    if request.method == "POST":
        data['email']=request.POST.get('email')
        data['password']=request.POST.get('password')
    if valiDateExistingorNOt(data,request):
        return redirect('home')
    else:
        return render_to_response('admin_login.html') 
def  valiDateExistingorNOt(data,request):
    email = data['email']   
    sel_qry="select * from four_a_design_app_user_list where email="+json.dumps(email)
    all_objects= user_list.objects.raw(sel_qry)
    user_info={"email":email}
    for p in all_objects:
        user_info["password"]=p.password
    isValidUser=False
    if "password" in user_info:
        if user_info['password'] == data["password"]:
            isValidUser=True
    return  isValidUser

def updateStatus(request):
    updateInfo=json.loads(request.GET.get('updateInfo'))
    print("updateInfo****",updateInfo)
    update_query ="update four_a_design_app_userapplication set status='"+updateInfo["status"]+"' where id = %s" % updateInfo["list_id"]
    cursor.execute(update_query)
    transaction.commit()
    #all_items=userApplication.objects.all
    res_obj = {"message":"success","data":"User "+updateInfo["status"]+" Successfully"}
    return HttpResponse(json.dumps(res_obj))
    #return render(request,'admin.html',{'all_items':all_items,'id':updateInfo["list_id"]})
def getUserdata(request,list_id):
    sel_qry='SELECT * FROM four_a_design_app_userapplication WHERE id = %s' % list_id
    all_objects= userApplication.objects.raw(sel_qry)
    product_dict={"list_id":list_id}
    for p in all_objects:
        product_dict["name"]=p.name
        product_dict["email"]=p.email
        product_dict["phone"]=p.phone
        product_dict["skills"]=p.skills
        product_dict["description"]=p.description
        product_dict["status"]=p.status
    return render(request,'home.html',{'all_items':all_objects,'id':list_id})
def userSubmission(request):
    dictObj={}
    for name, value in request.GET.items():
        dictObj[name]=value
    email=dictObj['email']
    name=dictObj['name']
    phone=dictObj['phone']
    skills=dictObj['skill']
    description=dictObj['description']
    insert_query ="""insert into four_a_design_app_userapplication(name,email,phone,skills,description,status) values(%s,%s,%s,%s,%s,%s)"""
    valuesArr=(name,email,phone,skills,description,"Submitted")
    cursor.execute(insert_query,valuesArr)
    transaction.commit()
    return render(request,'userApplication.html',{'message':"success"})

